This project uses KiCad for the EDA

http://kicad.sourceforge.net/wiki/index.php/Main_Page


Gerber Files:

rallylog-Back.gbl
rallylog-Front.gtl
rallylog-SilkS_Front.gto
rallylog-Mask_Back.gbs
rallylog-Mask_Front.gts
rallylog-PCB_Edges.gbr

Drill File:

rallylog.drl

Drill Settings:

Drill Units: Inches
Zero format: Suppress Trailing Zeros
Precision: 2:4
Origin: absolute





